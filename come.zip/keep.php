<?php

  ini_set('session.cookie_lifetime', 86400 * 7);
  ini_set('session.gc_maxlifetime', 86400 * 7);
  ini_set('session.save_path', 'c:/wamp/www/coming/sessions');
  session_start();
if (isset($_GET['ref'])) {
  $_SESSION['referral'] = $_GET['ref'];
}else{
   $_SESSION['referral'] = '99188jh';
}


?>
<!DOCTYPE html>

<html lang="en">
<head>
<title>Dadi.com.ng-Find Electricians-programmers and eventPlanner Nigeria</title>
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="description" content=" FIND / GET a programmer, electrician, graphic designer, painter, Advertise your service for free in Nigeria,portharcourt ">
<meta name="keywords" content=" programmer portharcourt Nigeria, graphic designer portharcourt Nigeria,painter portharcourt Nigeria, phoneLaptop Repairs Portharcourt Nigeria, ">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css"/>
<link rel="stylesheet" href="css1/bootstrap.css"/>
<script src="script/jquery-3.3.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Inria+Serif|Open+Sans+Condensed:300|Playfair+Display|Quicksand|Titillium+Web&display=swap" rel="stylesheet">

<style type="text/css">
    .write{
      font-family: 'Candara body copy';
      font-size: 15px;
    }
    #im{
      text-align: center;
    }
    #r{
      font-family:'Inria Serif', serif;
    }
    #ra{
      font-family:'Playfair Display', serif;
    }
    #rai{
      font-family:'Titillium Web', sans-serif;
    }

</style>
<script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 20, 2020 24:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
</head>
<body class="w3-card-4"  style=" position:absolute; max-width: 900px; margin: auto; left: 0; right: 0; top: 0px; height:600px;">
<div>
  <div class="w3-display-container" id="im" style="">
    <div  class="slides w3-display-container w3-black" style=" background-image:url('image/ch1.jpg'); background-color: black; background-repeat: no-repeat; background-position: center; background-size: cover; height:600px;top:-10px;width:inherit; "></div>
    <div class="" style="background-color: black; height: 600px; width:900px;">
 <p class="w3-margin-top" id="mesg"></p>
    <div class="w3-display-middle w3-text-white" style="width:auto; margin-top: 80px;">
      <div class="" id="r" style="letter-spacing: 0.4em; font-size:27px;">DADI</div>
      <p id="r" class="write w3-text-white " style="font-size: 22px;text-transform:capitalize; "> raise up your finance with DADI in 2020</p>
      <p id="r" style="font-size: 16px"> Get jobs daily at the comfort of your home</p>
      <p id="rai">COUNT DOWN TILL LAUNCH</p>
      <div id="demo" style="font-size: 20px"></div>




   <form action="" method="post" id="form" class="w3-container w3-card-4 ">
      <div>
        <label></label>
        <input class="w3-input w3-text-white w3-bottombar w3-border-white" id="email" style="background-color: rgb(0, 0, 0, 0.05); font-weight: bolder;" type="text" name="email" placeholder="Email">
      </div>
      <div>
        <label></label>
        <input class="w3-input w3-text-white w3-bottombar w3-border-white" id="phone" style="background-color: rgb(0, 0, 0, 0.05); font-weight: bolder;" type="tel" name="phone" placeholder="Phone Number">
        </div>
        <div><button class="w3-btn w3-card-4 w3-round-xxlarge" type='submit' id="submit" style="width:300px;margin-top: 10px; background-color:rgba(31, 171, 5, 0.6)!important;">Join Us</button></div>
    </div>
    </form>


</div>
    </div>
  </div>

</body>
</html>
 <script type="text/javascript">

    $(document).ready(function() {

      
    $("#form").submit(function(event){
   alert('insert');
      event.preventDefault();
      var email = $("#email").val();
      var phone = $("#phone").val();
      var submit = $("#submit").val();
alert(phone);
    
      $("#mesg").load("do.php", {

        email: email,
        phone: phone,
        submit: submit
         
      });
    });
    });
  </script>
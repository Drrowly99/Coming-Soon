<?php 

  ini_set('session.cookie_lifetime', 86400 * 7);
  ini_set('session.gc_maxlifetime', 86400 * 7);
  ini_set('session.save_path', 'c:/wamp/www/coming/sessions');
  session_start();

  include 'database.php';
  if (isset($_POST['submit'])){
  	 if (empty( $_POST['email'])) {
  	 	echo '<div class="w3-text-white " style="height:20px; width:50px;"> Please your email is required </div>';
  	 }elseif (empty( $_POST['phone'])) {
  	 	echo '<div class="w3-text-white " style="height:20px; width:50px;"> Please your phone number is required </div>', $_POST['phone'];
  	 }elseif (!filter_var( $_POST['email'], FILTER_VALIDATE_EMAIL)) {
  	 	echo '<div class="w3-text-white " style="height:20px; width:50px;"> Please your email is Invalid </div>', $_POST['phone'];
  	 }else{
  	 	$email =  strtolower(htmlspecialchars(mysqli_real_escape_string($conn, $_POST['email'])));
        $phone =  mysqli_real_escape_string($conn, $_POST['phone']);
        $token =  bin2hex(openssl_random_pseudo_bytes(7));
  	 	#check if email exista
  	 	# in database
  	   echo $_SESSION['referral'];
  	 	$query =  mysqli_query($conn,"SELECT * FROM `join` WHERE email = '$email' AND phone = '$phone' ");
        $valide = mysqli_num_rows($query);
        if ($valide > 0) {
        	echo '<div class="w3-text-white w3-white" style="height:20px; width:50px;"> email Already exists </div>';
        }else{
          $ref = $_SESSION['referral'];
        	$insert = mysqli_query($conn,"INSERT INTO `join` (email, phone, ref_token, u_token, ip ) VALUES ('$email', '$phone', '$ref', '$token', INET_ATON('192.168.0.10'))");
          if ($insert) {
          $check = mysqli_query($conn,"SELECT * FROM `join` WHERE email = '$email' ");
           $checkc = mysqli_num_rows($check);
            if($checkc > 0){
              while ($row = mysqli_fetch_assoc($check)) {
              $_SESSION['token'] = $row['u_token'] ;
              $_SESSION['id'] = $row['id'] ;
              $_SESSION['email'] = $row['email'] ;
              $_SESSION['phone'] = $row['phone'] ;
              $_SESSION['ref'] = $row['ref_token'] ;
              }
            }
             echo '<script> window.location.href="welcome.php?ref='.$_SESSION['ref'].'"</script>';
           
          }else{
            echo "failed";
          }
        }
  	 }
  		
  }



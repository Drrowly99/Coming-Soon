<?php 

  ini_set('session.cookie_lifetime', 86400 * 7);
  ini_set('session.gc_maxlifetime', 86400 * 7);
  ini_set('session.save_path', 'c:/wamp/www/coming/sessions');
  session_start();

 include 'database.php';
if (!isset($_SESSION['id'])) {
	  header('Location:home.php');
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<title>Dadi.com.ng-Find Electricians-programmers and eventPlanner Nigeria</title>
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="description" content=" FIND / GET a programmer, electrician, graphic designer, painter, Advertise your service for free in Nigeria,portharcourt ">
<meta name="keywords" content=" programmer portharcourt Nigeria, graphic designer portharcourt Nigeria,painter portharcourt Nigeria, phoneLaptop Repairs Portharcourt Nigeria, ">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css"/>
<link rel="stylesheet" href="css1/bootstrap.css"/>
<script src="script/jquery-3.3.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="https://fonts.googleapis.com/css?family=Inria+Serif|Open+Sans+Condensed:300|Playfair+Display|Quicksand|Titillium+Web&display=swap" rel="stylesheet">

<style type="text/css">
    .write{
      font-family: 'Candara body copy';
      font-size: 15px;
    }
    .f{
      margin-top:-20px;
      text-align: center;
      color:#2e0444;
    }.h{
      margin-top:-0px;
      text-align: center;
      color:#2e0444;
    }
    .w2-card-4{
    	box-shadow: 0 4px 10px 0 rgba(237, 215, 251, 0.37), 0 4px 20px 0 rgba(2, 2, 2, 0.19)
    }
      .w2-card{
      box-shadow: 0 4px 10px 0 rgba(237, 215, 251, 0.37), 0 4px 20px 0 rgba(2, 2, 2, 0.19)
    }
    .w2-btn,.w2-button{border:none;display:inline-block;vertical-align:middle;padding:5px;overflow:hidden;text-decoration:none;color:inherit;background-color:inherit;text-align:center;cursor:pointer;white-space:nowrap}

    
</style>
<div>
	
</div>
</head>
<body class="w2-card-4 w3-border w3-display-container"  style=" position:absolute; max-width: 900px; margin: auto; left: 0; right: 0; top: 0px; height:650px;">
	<div class="w3-card w3-white w3-container w3-display-container" style="position: relative; z-index:2; height:50px; max-width: 900px; margin-top: -1px;">
		<p class=" w3-display-leftmiddle" style="font-weight:bold">dadi.com.ng</p>
    <div class="w3-tiny w3-display-right w3-round-xlarge w3-padding w3-text-red logout" style="margin-right: 40%; background-color: rgba(242, 233, 249, 0.32);">logout</div>
		<div class=" w3-round-xlarge w3-padding w3-tiny w3-display-right " style="color: #2e0444; font-weight: bold; background-color: rgba(242, 233, 249, 0.32);" > <span id="stash"> 1,000 (stash) </span>  <span class="fa fa-money w3-text-green"></span></div>
	</div>
<div class=" w3-container w3-display-topmiddle " style="position:relative; line-height:;background-color: rgba(242, 233, 249, 0.32); height: 100px; width:95%;margin-top: 8px;">
	<p class="g w3-center" style="color: #2e0444;"><b>Thank You..!</b></p>
	<p class="f">You are now on our VIP list </p>
	<p class="f" style="line-height: px;">we have added your email address to the signup queue </p>
</div>

<div class="w3-white w3-row w3-text-black w3-round-large w3-display-topmiddle w3-margin-top w2-card-4" style="position:relative; font-size: 12px; height: 200px; width:85%;">
  <div class="w3-col s4 m4 l4 w3-green" style="height: 100px;"></div>
  <div class="w3-col s4 m4 l4 w3-white" style="height: 100px;"></div>
  <div class="w3-col s4 m4 l4 w3-green" style="height: 100px;"></div>

  
</div>



<div class="w3-white w3-container w3-text-black w3-round-large w3-display-topmiddle w3-leftbar w3-border-green " style="position:relative; font-size: 12px; margin-top: -110px; height: 160px; width:85%;">
	<span><img src="image/br.png" class="w3-display-topmiddle" style="height: 40px; margin-top: 5px; width:30px;"></span><p class="fa fa-medal w3-text-green"></p>
	<p class=" w3-center" style="color: #2e0444;margin-top: 20px; "><b>you have a bronze medal badge</b></p>
	<p class=" w3-center" style="margin-top: -10px;">you get 1,000 (stash) <span class="fa fa-money w3-text-green "></span> to bid for all the jobs on our platform</p>
	<p class=" w3-center " style="color: #2e0444; font-size: 10px;">With a GOLD badge, you get 100,000 (stash) <span class="fa fa-money w3-text-green" style="font-size: 14px"></span> to bid for as much jobs as you want </p>
</div>

<div class="w3-row w3-text-black w3-display-topmiddle w3-margin-top " style="background-color: rgba(242, 233, 249, 0.32); position:relative; font-size: 12px; height: 180px; width:96%;">
  <div class="w3-col  w3-white  w3-round-large " style="height: 150px; width:47%; margin-right: 1%;margin-left: 1.5%; margin-top:15px;">
   <img src="image/sil.png" class="" style="height: 40px;position: relative; left:50%;margin-left: -20px; margin-top: 5px; width:30px;">
   <p  class="w3-center" style="font-size:11px; color: #2e0444; "> Get <b class="" style="">10,000 (stash)</b> <span class="fa fa-money w3-text-green "></span></p>
   <p onclick="document.getElementById('id02').style.display='block'" class="w3-btn w3-text-white w3-center w3-round" style="font-size: 12px; width:80%; background-color: #cacacc; margin-left: 10%; color: #2e0444;">GET NOW..!</p>
   <p></p>
  </div>
  <div class="w3-col  w3-white w3-round-large" style="height: 150px; width:47%; margin-left: 1%; margin-right: 1.5%; margin-top:15px;">
    <img src="image/go.png" class="" style="height: 40px;position: relative; left:50%; margin-top: 5px;margin-left: -20px;  width:30px;">
    <p class="w3-center" style="font-size:11px;color: #2e0444;">Get <b class=""> 100,000 (stash)</b>  <span class="fa fa-money w3-text-green "></span></p>
   <p onclick="document.getElementById('id01').style.display='block'" class="w3-btn w3-center w3-round w3-text-white" style=" width: 80%; background-color: #e7af2b; margin-left: 10%;">GET NOW..!</p>
   <p></p>
  </div>
 <div id="bl" class="w3-text-white w3-round" onclick="document.getElementById('bl').style.display='none'"  style="background-color: rgba(0, 0, 0, 0.53); position: absolute; height: 50px; width: 100%;">
    <span  class="w3-red w3-round-xxlarge w3-small" style=" position: relative;top:15px; left:5px;padding: 2px 7px 3px 7px;">x</span>
    <div id="echo" class=" w3-round-xxlarge w3-small w3-center" style=" position: relative; top:-8px;"> </div>

  </div>
</div>




<div class="w3-container">
  <div id="id01" class="w3-modal" >
    <div class="w3-modal-content w3-container w3-card-4 w3-animate-zoom" style="max-width:600px ;margin-top:0px; height: 450px;">
      <div class="w3-center"><br>
        <span onclick="document.getElementById('id01').style.display='none'" class="w3-hide w3-btn w3-small w3-hover-text-red w3-display-topright" title="Close Modal">&times;</span>
        <p class="w3-small" style="color: #2e0444; ">Get a GOLD badge by Referring 2 friends </p>
      </div>
        <div class="" style="height: 60px; max-width: 100%; background-color: rgba(242, 233, 249, 0.32); ">
          <div class="w3-center w3-container" style="font-size:11px;""> This is your referral link, copy and send it to your friends </div>
          <p class="w3-small w3-center w3-text-blue"> dadi.com.ng?ref=<?php echo $_SESSION['id']?></p>
        </div>
        <div class="w3-center"> OR </div>
        <div class="w3-center" style="font-size:10px;"> Simply share this message on whatsapp </div>
        <div class="w3-dispay-container w3-container w3-leftbar w3-border-green w3-margin-top  w3-round" style="width:100%; height:100px; margin-top: -20px;background-color:rgba(207, 247, 195, 0.32); ">
          <p class="w3-white w3-center w3-card w3-round w3-border-grey" style=" font-size:9px; width:100%;" >text tod dhsgjhdjshjsdhsjdhjhjhjhdjdhsjdshjhdjdhsjhsjhsd dshsjh send on twitter dkdsjkdsj sdhjdsk jk dskj dskjsd ds kjdsdskj</p>
           <a href="https://api.whatsapp.com/send?text= text tod dhsgjhdjshjsdhsjdhjhjhjhdjdhsjdshjhdjdhsjhsjhsd dshsjh send on twitter dkdsjkdsj sdhjdsk jk dskj dskjsd ds kjdsdskj  www.dadi.com.ng/index.php?ref_id=<?php echo $_SESSION['id'];?>" data-action="share/whatsapp/share">
            <div class="w3-btn w3-white w3-round w3-card"  style="position: absolute; left: 50%; margin-left: -70px;width:140px; padding: 5px; font-size: 11px;"> 
              <span  class="fa fa-whatsapp w3-text-green w3-large" style="font-weight: bold;"></span> share on whatsapp</div></a>
        </div>

        <div class="w3-dispay-container w3-container w3-leftbar w3-border-blue w3-margin-top  w3-round" style="width:100%; height:100px; margin-top: -20px;background-color:rgba(199, 206, 243, 0.32); ">
          <p class="w3-white w3-center w3-card w3-round w3-border-grey" style=" font-size:9px; width:100%;" >text to send on twitter dkdsjk  hdfshsh sjhh hdshd  dshd hdhdjd shjdshdjdh jdshds jhdsjdshd shddsj sdhjdsk jk dskj dskjsd ds kjdsdskj</p>
          <div class="w3-btn w3-white w3-round w3-card"  style="position: absolute; left: 50%; margin-left: -70px;width:140px; padding: 5px; font-size: 11px;">     <a href="https://twitter.com/share?ref_src=twsrc%5Etfw" 
             class="twitter-share-button"
             data-text="Some sample text dfmhsdj" 
             data-via="QuotedReplies @Techpointdotng @microtraction @henryshield @Cc_HUB"  
             data-url="http://localhost/coming/welcome.php?ref=<?php echo $_SESSION['id'] ?>"  
             data-hashtags="FindjobwithDADI" 
             data-show-count="false">
              <span  class="fa fa-twitter w3-text-blue w3-large" style="font-weight: bold;"></span> share on twitter
             </a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></div>
        </div>


     </div>
    </div>
  </div>
</div>



<div class="w3-container">
  <div id="id02" class="w3-modal" >
    <div class="w3-modal-content w3-container w3-card-4 w3-animate-zoom" style="max-width:600px ;margin-top:0px; height: 450px;">
      <div class="w3-center"><br>
        <span onclick="document.getElementById('id02').style.display='none'" class="w3-hide w3-btn w3-small w3-hover-text-red w3-display-topright" title="Close Modal">&times;</span>
        <p class="w3-small" style="color: #2e0444; ">Get a SILVER badge by Referring 1 friends </p>
      </div>
        <div class="" style="height: 60px; max-width: 100%; background-color: rgba(242, 233, 249, 0.32); ">
          <div class="w3-center w3-container " style="font-size:11px;""> This is your referral link, copy and send it to your friends </div>
            <p class="w3-small w3-center w3-text-blue"> dadi.com.ng?ref=<?php echo $_SESSION['id']?></p>
        </div>
        <div class="w3-center"> OR </div>
        <div class="w3-center" style="font-size:10px;"> Simply share this message on whatsapp </div>
        <div class="w3-dispay-container w3-container w3-leftbar w3-border-green w3-margin-top  w3-round" style="width:100%; height:100px; margin-top: -20px;background-color:rgba(207, 247, 195, 0.32); ">
          <p class="w3-white w3-center w3-card w3-round w3-border-grey" style=" font-size:9px; width:100%;" >text tod dhsgjhdjshjsdhsjdhjhjhjhdjdhsjdshjhdjdhsjhsjhsd dshsjh send on twitter dkdsjkdsj sdhjdsk jk dskj dskjsd ds kjdsdskj</p>

          <div class="w3-btn w3-white w3-round w3-card"  style="position: absolute; left: 50%; margin-left: -70px;width:140px; padding: 5px; font-size: 11px;"> <span  class="fa fa-whatsapp w3-text-green w3-large" style="font-weight: bold;"></span> share on whatsapp</div><a href="https://api.whatsapp.com/send?text= text tod dhsgjhdjshjsdhsjdhjhjhjhdjdhsjdshjhdjdhsjhsjhsd dshsjh send on twitter dkdsjkdsj sdhjdsk jk dskj dskjsd ds kjdsdskj  www.dadi.com.ng/index.php?ref_id=<?php echo $_SESSION['id'];?>" data-action="share/whatsapp/share">
            <div class="w3-btn w3-white w3-round w3-card"  style="position: absolute; left: 50%; margin-left: -70px;width:140px; padding: 5px; font-size: 11px;"> 
              <span  class="fa fa-whatsapp w3-text-green w3-large" style="font-weight: bold;"></span> share on whatsapp</div></a>
        </div>

        <div class="w3-dispay-container w3-container w3-leftbar w3-border-blue w3-margin-top  w3-round" style="width:100%; height:100px; margin-top: -20px;background-color:rgba(199, 206, 243, 0.32); ">
          <p class="w3-white w3-center w3-card w3-round w3-border-grey" style=" font-size:9px; width:100%;" >text to send on twitter dkdsjk  hdfshsh sjhh hdshd  dshd hdhdjd shjdshdjdh jdshds jhdsjdshd shddsj sdhjdsk jk dskj dskjsd ds kjdsdskj</p>
           <div class="w3-btn w3-white w3-round w3-card"  style="position: absolute; left: 50%; margin-left: -70px;width:140px; padding: 5px; font-size: 11px;">
          <a href="https://twitter.com/share?ref_src=twsrc%5Etfw" 
             class="twitter-share-button"
             data-text="Some sample text dfmhsdj" 
             data-via="QuotedReplies @Techpointdotng @microtraction @henryshield @Cc_HUB"  
             data-url="http://localhost/coming/welcome.php?ref=<?php echo $_SESSION['id'] ?>"  
             data-hashtags="FindjobwithDADI" 
             data-show-count="false">
              <span  class="fa fa-twitter w3-text-blue w3-large" style="font-weight: bold;"></span> share on twitter
             </a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></div>
        </div>


     </div>
    </div>
  </div>
</div>
</div>
<footer>
   
  <div class="w3-black w3-text-white" style="height: 50px; width: 100%;">
  <div class="w3-center w3-small w3-padding">Powered and designed by DADI_TEAM  </div>
  <div class="w3-center w3-tiny ">@DADI.COM.NG 2019, DEC </div>
</div>
</footer>
<div id="email"></div>
</body>
</html>
 <script >
$(document).ready(function(){
    var check = '<?php echo $_SESSION['ref']  ?>'
    $("#echo").load("data.php", {check: check});
   });
</script>

 <script >
$(document).ready(function(){
    var email = '<?php echo $_SESSION['id']  ?>'
    $("#email").load("data.php", {email: email});
   });
</script>

 <script >
$(document).ready(function(){
  var refresh = setInterval(function(){
    var stash = '<?php echo $_SESSION['ref']  ?>';
    $("#stash").load("data.php", {stash: stash});
  }, 10000);
});
</script>

 <script >
$(document).ready(function(){
$(".logout").click(function(){
   window.location.href = "out.php";
  });
});
</script>

   
<?php

  ini_set('session.cookie_lifetime', 86400 * 7);
  ini_set('session.gc_maxlifetime', 86400 * 7);
  ini_set('session.save_path', 'c:/wamp/www/coming/sessions');
  session_start();
if (isset($_GET['ref'])) {
  $_SESSION['referral'] = $_GET['ref'];
}else{
   $_SESSION['referral'] = '99188jh';
}
if (isset($_SESSION['id'])) {
echo '<script> window.location.href="welcome"</script>';
}

?>
<!DOCTYPE html>

<html lang="en">
<head>
<title>Dadi.com.ng-Find Electricians-programmers and eventPlanner Nigeria</title>
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="description" content=" FIND / GET a programmer, electrician, graphic designer, painter, Advertise your service for free in Nigeria,portharcourt ">
<meta name="keywords" content=" programmer portharcourt Nigeria, graphic designer portharcourt Nigeria,painter portharcourt Nigeria, phoneLaptop Repairs Portharcourt Nigeria, ">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css"/>
<link rel="stylesheet" href="css1/bootstrap.css"/>
<script src="script/jquery-3.3.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Inria+Serif|Open+Sans+Condensed:300|Playfair+Display|Quicksand|Titillium+Web&display=swap" rel="stylesheet">
    <script type="text/javascript">
$(document).ready(function() {
        $('#image').css({"background-image":"url('image/ch3..jpg')"})
})
    setTimeout(function(){
       $('#image').css({"background-image":"url('image/ch1.jpg')"})
    }, 100)

    </script>
<style type="text/css">
    .write{
      font-family: 'Candara body copy';
      font-size: 15px;
    }
    #im{
      text-align: center;
    }
    #r{
      font-family:'Inria Serif', serif;
    }
    #ra{
      font-family:'Playfair Display', serif;
    }
    #rai{
      font-family:'Titillium Web', sans-serif;
    }

</style>

</head>
<body class="w3-card-4"  style=" position:absolute; max-width: 900px; margin: auto; left: 0; right: 0; top: 0px; height:600px;">
    <div id="image" class="im" style=" height:600px;width: inherit;background-repeat: no-repeat; background-position: center; background-size: cover;">
      <div class="" style="background-color: rgba(0, 0, 0, 0.65); height: 600px; width: 100%;">
        <div class="w3-display-middle w3-text-white" style="width:auto; margin-top: 80px;">
        <div id="r" class="w3-center" style="letter-spacing: 0.4em; font-size:27px;">DADI</div>
        <p id="r" class="write w3-text-white w3-center" style="font-size: 18px;text-transform:capitalize; ">get jobs in nigeria without a resume or CV </p>
        <p id="r" class="w3-center" style="font-size: 16px;text-transform:capitalize; margin-top: -25px"> all you need is your skills and experience </p>
        <p id="rai" class="w3-center " style="font-size: 9px;">LAUNCH BEGINS IN</p>
        <div class="w3-center" id="demo" style="font-size: 20px"></div>
        <div id="mesg" style="font-size: 20px"></div>
        <form action="" method="post" id="form" class="w3-container w3-card-4" style="margin-top: 10px; ">
          <div>
            <label></label>
            <input class="w3-input w3-text-white" id="email" style="border:2px white solid;background-color: rgb(0, 0, 0, 0.05); font-weight: bolder;" type="text" name="email" placeholder="Email">
          </div>
          <div>
            <label></label>
            <input class="w3-input w3-text-white " id="phone" style="border:2px white solid;background-color: rgb(0, 0, 0, 0.05); margin-top: 10px; font-weight: bolder;" type="tel" name="phone" placeholder="Phone Number">
            </div>
            <div><button class="w3-btn w3-card-4 w3-small w3-round w3-text-black " type='submit' id="submit" style="position:relative; background-color: rgb(255, 255, 255)!important;border:2px white solid;  margin-top: 10px;">Get Early Access</button></div>
        </div>
      </form>
      </div></div>
      
    </div>
</body>
</html>

 <script type="text/javascript">

    $(document).ready(function() {

      
    $("#form").submit(function(event){

      event.preventDefault();
      var email = $("#email").val();
      var phone = $("#phone").val();
      var submit = $("#submit").val();

    
      $("#mesg").load("do.php", {

        email: email,
        phone: phone,
        submit: submit
         
      });
    });
    });
  </script>
  <script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 20, 2020 24:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "D " + hours + "Hrs "
  + minutes + "Min " + seconds + "Sec ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>